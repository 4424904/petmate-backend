package com.petmate.common.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class FileUtil {

    @Value("${app.upload.dir:${user.home}/petmate/uploads}")
    private String uploadRoot; // 절대 루트

    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS");

    public String save(MultipartFile file, String subDir) {
        try {
            // sanitize
            String original = StringUtils.cleanPath(file.getOriginalFilename());
            String sanitized = original.replaceAll("[\\\\/:*?\"<>|]", "_");   // 윈도우 금지문자 제거
            String filename = TS.format(LocalDateTime.now()) + "_" + sanitized;

            Path base = Paths.get(uploadRoot).toAbsolutePath().normalize();
            Path targetDir = base.resolve(normalizeSubDir(subDir)).normalize();
            Files.createDirectories(targetDir);

            Path target = targetDir.resolve(filename);
            try (InputStream in = file.getInputStream()) {
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
            }

            // 정적 서빙용 URL 경로 반환
            String webPath = "/uploads/" + normalizeSubDir(subDir).replace("\\", "/") + "/" + filename;
            return webPath.replaceAll("//+", "/");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String normalizeSubDir(String subDir) {
        if (subDir == null) return "";
        // 이메일 등 폴더명에 안전하지 않은 문자를 '_'로 치환
        return subDir.replaceAll("[^a-zA-Z0-9._/\\-]", "_").replaceAll("^/+", "").replaceAll("/+$", "");
    }
}
