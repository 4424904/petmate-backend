package com.petmate.common.util;
import java.util.Map;
import java.util.List;

public final class CodeMapper {
    private CodeMapper(){}

    private static final Map<String,String> SVC = Map.of(
            "돌봄","C", "산책","W", "미용","B", "병원","H", "기타","O"
    );
    private static final Map<String,String> SPEC = Map.of(
            "강아지","D", "고양이","C", "기타","O"
    );

    public static String mainService(List<String> services){
        if (services==null || services.isEmpty()) return null;
        return SVC.getOrDefault(services.get(0), "O");
    }
    public static String careSpecies(List<String> pets){
        if (pets==null || pets.isEmpty()) return null;
        if (pets.contains("강아지")) return "D";
        if (pets.contains("고양이")) return "C";
        return "O";
    }
}
