package com.petmate.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = {
        "com.petmate.domain",   // 모든 도메인의 JPA 리포지토리 스캔
        "com.petmate.common"
})
@EntityScan(basePackages = {
        "com.petmate.domain",   // 모든 엔티티 스캔
        "com.petmate.common"
})
public class JpaConfig { }
