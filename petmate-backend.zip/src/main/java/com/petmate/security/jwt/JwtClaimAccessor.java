package com.petmate.security.jwt;

import io.jsonwebtoken.Claims;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class JwtClaimAccessor {

    // === write ===
    public static Map<String, Object> accessClaims(
            List<String> roles,
            String provider,
            String email,
            String nickname,
            String name,
            String picture
    ) {
        Map<String, Object> c = new HashMap<>();
        c.put("typ", "access");
        c.put("roles", roles);
        c.put("prov", provider);
        if (email != null)    c.put("email", email);
        if (nickname != null) c.put("nickname", nickname);
        if (name != null)     c.put("name", name);
        if (picture != null)  c.put("picture", picture);
        return c;
    }

    public static Map<String, Object> refreshClaims() {
        Map<String, Object> c = new HashMap<>();
        c.put("typ", "refresh");
        c.put("jti", UUID.randomUUID().toString());
        return c;
    }

    // === read (for filters/controllers) ===
    public static String type(Claims claims) {
        Object v = claims.get("typ");
        return v == null ? null : String.valueOf(v);
    }
    @SuppressWarnings("unchecked")
    public static List<String> roles(Claims claims) {
        Object v = claims.get("roles");
        return v instanceof List ? (List<String>) v : List.of();
    }
    public static String provider(Claims claims) {
        Object v = claims.get("prov");
        return v == null ? null : String.valueOf(v);
    }
    public static String email(Claims claims) {
        Object v = claims.get("email");
        return v == null ? null : String.valueOf(v);
    }
    public static String nickname(Claims claims) {
        Object v = claims.get("nickname");
        return v == null ? null : String.valueOf(v);
    }
    public static String name(Claims claims) {
        Object v = claims.get("name");
        return v == null ? null : String.valueOf(v);
    }
    public static String picture(Claims claims) {
        Object v = claims.get("picture");
        return v == null ? null : String.valueOf(v);
    }
}
