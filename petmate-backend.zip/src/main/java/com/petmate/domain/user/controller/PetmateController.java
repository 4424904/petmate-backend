package com.petmate.domain.user.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.petmate.domain.user.dto.request.PetmateRequestDto;
import com.petmate.domain.user.service.PetmateService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/petmate")
public class PetmateController {
    private final PetmateService petmateService;
    private final ObjectMapper om = new ObjectMapper();

    // PetmateController.java (교체)
    @PostMapping(value="/apply", consumes={"multipart/form-data"})
    public void apply(
            @RequestPart("name") String name,
            @RequestPart("gender") String gender,
            @RequestPart("age") String age,
            @RequestPart("hasCar") String hasCar,
            @RequestPart("services") String servicesJson,
            @RequestPart("pets") String petsJson,
            @RequestPart(value="profile", required=false) MultipartFile profile,
            @RequestPart(value="certificates", required=false) List<MultipartFile> certificates,
            @AuthenticationPrincipal OAuth2User oauth2,  // 소셜 로그인 시
            org.springframework.security.core.Authentication auth // JWT 시
    ) throws Exception {

        var services = om.readValue(servicesJson, new TypeReference<List<String>>() {});
        var pets     = om.readValue(petsJson,     new TypeReference<List<String>>() {});
        var dto = new PetmateRequestDto(name, gender, Integer.valueOf(age),
                Boolean.valueOf(hasCar), services, pets, profile, certificates);

        // 1) OAuth2
        String email=null, provider=null, nick=null, picture=null;
        if (oauth2 != null) {
            email    = oauth2.getAttribute("email");
            provider = oauth2.getAttribute("provider");
            if (provider == null) provider = resolveProviderFromAuthorities(oauth2);
            nick     = oauth2.getAttribute("name");
            picture  = oauth2.getAttribute("picture");
        }
        // 2) JWT (JwtAuthenticationFilter가 setName(email) 했다는 전제)
        if (email == null && auth != null) {
            email = auth.getName();
            provider = "JWT";
            nick = (nick == null ? email : nick);
        }
        if (email == null) throw new org.springframework.web.server.ResponseStatusException(
                org.springframework.http.HttpStatus.UNAUTHORIZED, "로그인 필요");

        petmateService.apply(dto, email, provider, nick, picture);
    }

    private String resolveProviderFromAuthorities(OAuth2User p){
        return p.getAuthorities().stream().findFirst()
                .map(a -> a.getAuthority().replace("ROLE_OAUTH2_", "")) // 예: ROLE_OAUTH2_GOOGLE
                .orElse("GOOGLE");
    }
}
