package com.petmate.domain.user.service;

import com.petmate.domain.img.entity.ProfileImageMap;
import com.petmate.domain.img.repository.ProfileImageMapRepository;
import com.petmate.domain.user.entity.PetmateCertEntity;
import com.petmate.domain.user.entity.UserEntity;
import com.petmate.domain.user.repository.jpa.PetmateCertRepository;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class UserFileService {

    @Value("${app.upload.dir:C:/petmate}")
    private String uploadRoot;

    private final PetmateCertRepository certRepository;
    private final ProfileImageMapRepository imageMapRepo;

    public String storeProfile(UserEntity user, MultipartFile file) {
        if (file == null || file.isEmpty()) return user.getProfileImage();

        String ext = FilenameUtils.getExtension(file.getOriginalFilename());
        if (ext == null || ext.isBlank()) ext = "png";
        String uuid = UUID.randomUUID().toString() + "." + ext;

        Path savePath = Paths.get(uploadRoot, String.valueOf(user.getId()), "profile", uuid);
        try {
            Files.createDirectories(savePath.getParent());
            file.transferTo(savePath.toFile());
        } catch (IOException e) {
            throw new RuntimeException("프로필 저장 실패", e);
        }

        // ⚠️ 이메일 중복 저장 방지
        if (imageMapRepo.findByEmail(user.getEmail()).isEmpty()) {
            imageMapRepo.save(ProfileImageMap.builder()
                    .uuid(uuid)
                    .email(user.getEmail())
                    .realPath(savePath.toString())
                    .build());
        }

        user.setProfileImage(uuid);
        return uuid;
    }

    public String storeProfileFromUrl(UserEntity user, String imageUrl) {
        try (InputStream is = new URL(imageUrl).openStream()) {
            byte[] bytes = is.readAllBytes();

            String ext = FilenameUtils.getExtension(imageUrl);
            if (ext == null || ext.isBlank()) ext = "png";
            String uuid = UUID.randomUUID().toString() + "." + ext;

            Path savePath = Paths.get(uploadRoot, String.valueOf(user.getId()), "profile", uuid);
            Files.createDirectories(savePath.getParent());
            Files.write(savePath, bytes);

            if (imageMapRepo.findByEmail(user.getEmail()).isEmpty()) {
                imageMapRepo.save(ProfileImageMap.builder()
                        .uuid(uuid)
                        .email(user.getEmail())
                        .realPath(savePath.toString())
                        .build());
            }

            user.setProfileImage(uuid);
            return uuid;
        } catch (IOException e) {
            throw new RuntimeException("프로필(URL) 저장 실패", e);
        }
    }

    public String storeDefaultProfileIfAbsent(UserEntity user) {
        String cur = user.getProfileImage();
        if (cur != null && !cur.isBlank()) return cur;

        try (InputStream is = getClass().getClassLoader().getResourceAsStream("static/profiles/default.png")) {
            if (is == null) throw new IOException("default.png 리소스 없음");
            byte[] bytes = is.readAllBytes();

            String uuid = UUID.randomUUID().toString() + ".png";
            Path savePath = Paths.get(uploadRoot, String.valueOf(user.getId()), "profile", uuid);
            Files.createDirectories(savePath.getParent());
            Files.write(savePath, bytes);

            if (imageMapRepo.findByEmail(user.getEmail()).isEmpty()) {
                imageMapRepo.save(ProfileImageMap.builder()
                        .uuid(uuid)
                        .email(user.getEmail())
                        .realPath(savePath.toString())
                        .build());
            }

            user.setProfileImage(uuid);
            return uuid;
        } catch (IOException e) {
            throw new RuntimeException("기본 프로필 저장 실패", e);
        }
    }

    public List<String> storeCertificates(UserEntity user, List<MultipartFile> files) {
        List<String> uuids = new ArrayList<>();
        if (files == null || files.isEmpty()) return uuids;

        for (MultipartFile file : files) {
            if (file.isEmpty()) continue;

            String ext = FilenameUtils.getExtension(file.getOriginalFilename());
            if (ext == null || ext.isBlank()) ext = "png";

            String uuid = UUID.randomUUID().toString() + "." + ext;
            uuids.add(uuid);

            Path savePath = Paths.get(uploadRoot, String.valueOf(user.getId()), "certs", uuid);
            try {
                Files.createDirectories(savePath.getParent());
                file.transferTo(savePath.toFile());
            } catch (IOException e) {
                throw new RuntimeException("자격증 저장 실패", e);
            }

            PetmateCertEntity cert = PetmateCertEntity.builder()
                    .userId(user.getId())
                    .uuidName(uuid)
                    .filePath(savePath.toString())
                    .originalName(file.getOriginalFilename())
                    .build();

            certRepository.save(cert);
        }

        return uuids;
    }
}
