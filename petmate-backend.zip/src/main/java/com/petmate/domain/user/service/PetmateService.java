// src/main/java/com/petmate/domain/user/service/PetmateService.java
package com.petmate.domain.user.service;

import com.petmate.domain.user.dto.request.PetmateRequestDto;
import com.petmate.domain.user.entity.UserEntity;
import com.petmate.domain.user.repository.jpa.UserRepository;
import com.petmate.common.util.CodeMapper;
import com.petmate.common.util.FileUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@RequiredArgsConstructor
public class PetmateService {
    private final UserRepository userRepo;
    private final FileUtil fileUtil;

    @Transactional
    public void apply(PetmateRequestDto req,
                      String email, String provider,
                      String socialNick, String socialPicture){

        UserEntity u = userRepo.findByEmail(email).orElseGet(UserEntity::new);
        u.setEmail(email);
        u.setProvider(provider);
        u.setNickName(socialNick);
        u.setName((req.name()!=null && !req.name().isBlank()) ? req.name()
                : (u.getName()!=null ? u.getName() : socialNick));
        u.setGender(empty(req.gender()) ? u.getGender() : req.gender());
        u.setMainService(CodeMapper.mainService(req.services()));
        u.setCareSpecies(CodeMapper.careSpecies(req.pets()));
        u.setStatus("A");

        // 프로필 저장
        MultipartFile pf = req.profile();
        String emailDir = "profiles/" + safe(email);
        if (pf != null && !pf.isEmpty()){
            String path = fileUtil.save(pf, emailDir);
            u.setProfileImage(path);
        } else if (u.getProfileImage()==null && socialPicture!=null){
            u.setProfileImage(socialPicture);
        }

        userRepo.save(u); // ID 확보

        // 자격증 저장(옵션)
        if (req.certificates()!=null){
            String certDir = "certs/" + u.getId();
            for (MultipartFile f : req.certificates()){
                if (f!=null && !f.isEmpty()){
                    fileUtil.save(f, certDir);
                }
            }
        }
    }

    private boolean empty(String s){ return s==null || s.isBlank(); }
    private String safe(String s){ return s==null ? "unknown" : s.replaceAll("[^a-zA-Z0-9._-]", "_"); }
}
