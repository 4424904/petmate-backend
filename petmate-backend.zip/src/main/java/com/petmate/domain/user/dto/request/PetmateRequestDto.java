package com.petmate.domain.user.dto.request;

import org.springframework.web.multipart.MultipartFile;
import java.util.List;

public record PetmateRequestDto(
        String name,
        String gender,          // "M"|"F"|"N"
        Integer age,
        Boolean hasCar,
        List<String> services,  // ["돌봄",...]
        List<String> pets,      // ["강아지",...]
        MultipartFile profile,
        List<MultipartFile> certificates
) {}
