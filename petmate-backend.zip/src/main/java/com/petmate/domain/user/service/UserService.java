package com.petmate.domain.user.service;

import com.petmate.domain.user.dto.request.PetmateApplyRequest;
import com.petmate.domain.user.entity.UserEntity;
import com.petmate.domain.user.factory.UserFactory;
import com.petmate.domain.user.repository.jpa.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

@Service
@RequiredArgsConstructor
public class UserService {

    @Value("${app.public-img-url}")
    private String imageBaseUrl;

    private final UserRepository userRepository;
    private final UserFactory userFactory;
    private final UserFileService userFileService;

    /** 펫메이트 신청 (파일 포함) */
    @Transactional
    public Integer apply(String email, PetmateApplyRequest req) {
        // 생성 or 조회
        UserEntity user = userRepository.findByEmail(email).orElseGet(() ->
                userRepository.save(userFactory.create(email, req.getName(), req.getNickName(),
                        req.getProvider(), req.getPhone(), "3", "2")));

        // 갱신
        userFactory.update(user, req.getName(), req.getNickName(), req.getPhone(),
                req.getGender(), req.getAge(), req.getProvider());

        // 파일 저장
        userFileService.storeProfile(user, req.getProfile());
        userRepository.save(user);
        userFileService.storeCertificates(user, req.getCertificates());

        return user.getId();
    }

    @Transactional
    public Integer applyBasicUser(String email,
                                  String provider,
                                  String name,
                                  String nickName,
                                  String phone,
                                  String gender,
                                  Integer age,
                                  String profileImageUrl) { // ✅ URL 추가

        UserEntity user = userRepository.findByEmail(email).orElseGet(() ->
                userRepository.save(userFactory.create(email, name, nickName, provider, phone, "1", "1")));

        userFactory.update(user, name, nickName, phone, gender, age, provider);

        if (profileImageUrl != null && !profileImageUrl.isBlank()) {
            userFileService.storeProfileFromUrl(user, profileImageUrl); // ✅ URL 처리 추가
        } else {
            userFileService.storeDefaultProfileIfAbsent(user);
        }

        userRepository.save(user);
        return user.getId();
    }

    public String findProfileImageByEmail(String email) {
        String uuidPath = userRepository.findByEmail(email)
                .map(UserEntity::getProfileImage)
                .orElse("profiles/default.png");  // 이건 경로만 (절대 URL 아님)

        return imageBaseUrl + uuidPath;
    }
}
