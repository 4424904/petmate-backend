package com.petmate.domain.user.entity;

import jakarta.persistence.*;
import lombok.Getter; import lombok.Setter;

@Getter @Setter
@Entity @Table(name="user",
        indexes = {@Index(name="uk_user_email", columnList="EMAIL", unique=true)})
public class UserEntity {

    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="ID") private Integer id;

    @Column(name="EMAIL", nullable=false, unique=true) private String email;
    @Column(name="ADDRESS") private String address;
    @Column(name="NICK_NAME") private String nickName;
    @Column(name="PROVIDER", nullable=false) private String provider; // KAKAO/NAVER/GOOGLE
    @Column(name="NAME", nullable=false) private String name;
    @Column(name="PROFILE_IMAGE", length=500) private String profileImage;
    @Column(name="PHONE", unique=true) private String phone;
    @Column(name="BIRTH_DATE") private java.sql.Date birthDate;
    @Column(name="GENDER", length=1) private String gender;          // M/F/N
    @Column(name="ROLE", length=1, nullable=false) private String role = "1";
    @Column(name="MAIN_SERVICE", length=1) private String mainService;
    @Column(name="CARE_SPECIES", length=1) private String careSpecies;
    @Column(name="STATUS", length=1, nullable=false) private String status = "A";
    @Column(name="EMAIL_VERIFIED", nullable=false) private Integer emailVerified = 0;
    @Column(name="CREATED_AT", insertable=false, updatable=false,
            columnDefinition="DATETIME DEFAULT CURRENT_TIMESTAMP")
    private java.time.LocalDateTime createdAt;
    @Column(name="UPDATED_AT", insertable=false, updatable=false,
            columnDefinition="DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP")
    private java.time.LocalDateTime updatedAt;
}
