package com.petmate.domain.auth.service;

import com.petmate.common.repository.mybatis.token.RefreshTokenMapper;
import com.petmate.common.repository.mybatis.user.MemberMapper;
import com.petmate.domain.auth.dto.request.LoginRequestDto;
import com.petmate.domain.auth.dto.request.SignupRequestDto;
import com.petmate.domain.auth.dto.response.TokenResponseDto;
import com.petmate.domain.auth.dto.response.MemberDto;
import com.petmate.security.jwt.JwtClaimAccessor;
import com.petmate.security.jwt.JwtUtil;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final MemberMapper memberMapper;
    private final RefreshTokenMapper refreshTokenMapper;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    // 로그인
    public TokenResponseDto signin(LoginRequestDto request) {
        MemberDto member = memberMapper.findById(request.getId());
        if (member == null) throw new RuntimeException("존재하지 않는 아이디입니다.");
        if (!passwordEncoder.matches(request.getPw(), member.getPw()))
            throw new RuntimeException("비밀번호가 올바르지 않습니다.");

        String accessToken = jwtUtil.issue(
                member.getId(),
                jwtUtil.accessTtlMs(),
                JwtClaimAccessor.accessClaims(
                        List.of("USER"),   // roles
                        "LOCAL",           // provider
                        member.getMail(),  // email
                        null,              // nickname
                        null,              // name
                        null               // picture
                )
        );

        String refreshToken = jwtUtil.issue(
                member.getId(),
                jwtUtil.refreshTtlMs(),
                JwtClaimAccessor.refreshClaims()
        );

        refreshTokenMapper.saveToken(member.getNo(), refreshToken);
        return new TokenResponseDto(accessToken, refreshToken);
    }

    // RefreshToken으로 AccessToken 재발급
    public TokenResponseDto refreshAccessToken(String refreshToken) {
        if (jwtUtil.isExpired(refreshToken))
            throw new RuntimeException("RefreshToken이 만료되었습니다. 다시 로그인하세요.");

        Claims claims = jwtUtil.parse(refreshToken);
        if (!"refresh".equals(JwtClaimAccessor.type(claims)))
            throw new RuntimeException("유효하지 않은 토큰 유형입니다.");

        String userId = claims.getSubject();

        String newAccessToken = jwtUtil.issue(
                userId,
                jwtUtil.accessTtlMs(),
                JwtClaimAccessor.accessClaims(
                        List.of("USER"),
                        "LOCAL",
                        null,  // email
                        null,  // nickname
                        null,  // name
                        null   // picture
                )
        );

        return new TokenResponseDto(newAccessToken);
    }

    // 회원가입
    public void signup(SignupRequestDto request) {
        String encodedPw = passwordEncoder.encode(request.getPw());
        MemberDto member = MemberDto.builder()
                .id(request.getId())
                .pw(encodedPw)
                .mail(request.getMail())
                .build();
        memberMapper.signup(member);
    }

    // 로그아웃
    public void signout(String refreshToken) {
        refreshTokenMapper.deleteByToken(refreshToken);
    }
}
