package com.petmate.domain.payment.entity;


public class PaymentRequest {



}
