package com.petmate.domain.img.service;

import com.petmate.domain.img.entity.ProfileImageMap;
import com.petmate.domain.img.repository.ProfileImageMapRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProfileImageService {

    private final ProfileImageMapRepository repo;

    /**
     * 이메일 기준으로 UUID가 있으면 재사용, 없으면 새로 생성 후 저장
     */
    public String getOrCreateUuidByEmail(String email, String pictureUrl) {
        return repo.findByEmail(email)
                .map(ProfileImageMap::getUuid)
                .orElseGet(() -> {
                    if (pictureUrl == null || pictureUrl.isBlank()) return null;

                    String ext = guessExt(pictureUrl);
                    String uuid = UUID.randomUUID().toString() + "." + ext;
                    String realPath = "C:/petmate/profile/" + uuid;

                    download(pictureUrl, realPath);

                    // ✅ Builder 사용 (createdAt, expiresAt 자동 처리)
                    repo.save(ProfileImageMap.builder()
                            .uuid(uuid)
                            .email(email)
                            .realPath(realPath)
                            .build());

                    return uuid;
                });
    }

    /**
     * UUID를 받아서 실제 로컬 경로 반환
     */
    public String resolveRealPath(String uuid) {
        return repo.findById(uuid)
                .map(ProfileImageMap::getRealPath)
                .orElse(null);
    }

    /**
     * URL에서 파일 확장자 추출 (없으면 png 기본값)
     */
    private String guessExt(String url) {
        int i = url.lastIndexOf('.');
        return (i > 0) ? url.substring(i + 1).toLowerCase() : "png";
    }

    /**
     * URL에서 지정된 로컬 경로로 이미지 다운로드
     */
    private void download(String url, String path) {
        try (InputStream in = new URL(url).openStream()) {
            Files.copy(in, Paths.get(path));
        } catch (IOException e) {
            throw new RuntimeException("프로필 이미지 다운로드 실패", e);
        }
    }
}
